This project's purpose is to develop all components located in the back end for the complete app.
  
Travis CI Status [![Build Status](https://travis-ci.org/AVE-cesar/AngularDemoBackend.svg)](https://travis-ci.org/AVE-cesar/AngularDemoBackend)

https://travis-ci.org/AVE-cesar/AngularDemoBackend.

[![Quality Gate](https://sonarqube.com/api/badges/gate?key=test:AngularDemoBackend)](https://sonarqube.com/dashboard/index/AngularDemoBackend)

https://sonarcloud.io/organizations/ave-cesar-github/projects

[![codecov](https://codecov.io/gh/AVE-cesar/AngularDemoBackend/branch/master/graph/badge.svg)](https://codecov.io/gh/AVE-cesar/AngularDemoBackend)

