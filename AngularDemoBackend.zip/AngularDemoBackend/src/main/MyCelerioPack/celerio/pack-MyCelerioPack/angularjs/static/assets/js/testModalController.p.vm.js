$output.resource("static\assets\js", "testModalController.js")##
