package com.jaxio.demo.jpa.model;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jaxio.demo.utils.AppAuthorityEntityTestUtils;

public class AppUserTest {

	private final Logger LOGGER = LoggerFactory.getLogger(AppUserTest.class);

	@Test
	public void testEquals() {
		AppAuthority appAuthority = AppAuthorityEntityTestUtils.createNewAppAuthority();
		List<AppAuthority> appAuthorities = new ArrayList<>();
		appAuthorities.add(appAuthority);

		AppUser user1 = new AppUser();
		user1.setAppAuthorities(appAuthorities);
		
		LOGGER.info(user1.getAppAuthorities().toString());
	}
}
